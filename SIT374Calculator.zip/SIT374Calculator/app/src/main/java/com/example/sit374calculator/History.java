package com.example.sit374calculator;

import android.app.Activity;
import android.hardware.display.DisplayManager;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class History extends Activity {

    ListView historyTextView;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setContentView(R.layout.history_popup);

        DisplayMetrics dm = new DisplayMetrics();
        getWindowManager().getDefaultDisplay().getMetrics(dm);

        int width = dm.widthPixels;
        int height = dm.heightPixels;

        getWindow().setLayout((int)( width*.9), (int)( height*.8));

        initTextView();

        ArrayList<String> newHistoryArray = (ArrayList<String>) getIntent().getSerializableExtra("key");

        //for (int i = 0; i < newHistoryArray.size(); i++) {
        //    historyTextView.setText(newHistoryArray.get(i));
        //}
        //historyTextView.setText(String.valueOf(newHistoryArray));

        ArrayAdapter adapter = new ArrayAdapter(History.this, android.R.layout.simple_list_item_1, newHistoryArray);
        historyTextView.setAdapter(adapter);
    }

    private void initTextView() {
        historyTextView = (ListView) findViewById(R.id.historyTextView);
    }
}
