package com.example.sit374calculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.reflect.Array;
import java.util.ArrayList;

import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

public class MainActivity extends AppCompatActivity {

    TextView workingsTextView, resultsTextView;

    String working = "";
    boolean leftBracket = true;
    ArrayList<String> historyArray = new ArrayList();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initTextViews();
    }

    private void initTextViews() {
        workingsTextView = (TextView)findViewById(R.id.workingsTextView);
        resultsTextView = (TextView)findViewById(R.id.resultTextView);
    }

    public void setWorking(String value){
        working = working + value;
        workingsTextView.setText(working);
    }

    public void equalsOnClick(View view) {
        Double result = null;
        ScriptEngine engine = new ScriptEngineManager().getEngineByName("rhino");

        try {
            result = (double) engine.eval(working);
        } catch (ScriptException e) {
            Toast.makeText(this, "Input Invalid", Toast.LENGTH_SHORT).show();
        }

        if(result != null) {
            resultsTextView.setText(String.valueOf(result.doubleValue()));
        }

        historyArray.add(working + " = " + result);
    }

    public void clearOnClick(View view) {
        workingsTextView.setText("");
        working = "";
        resultsTextView.setText("");
        leftBracket = true;
    }

    public void bracketsOnClick(View view) {
        if(leftBracket){
            setWorking("(");
            leftBracket = false;
        }
        else{
            setWorking(")");
            leftBracket = true;
        }
    }

    public void percentageOnClick(View view) {
        setWorking("%");
    }

    public void divideOnClick(View view) {
        setWorking("/");
    }

    public void sevenOnClick(View view) {
        setWorking("7");
    }

    public void eightOnClick(View view) {
        setWorking("8");
    }

    public void nineOnClick(View view) {
        setWorking("9");
    }

    public void multiplyOnClick(View view) {
        setWorking("*");
    }

    public void fourOnClick(View view) {
        setWorking("4");
    }

    public void fiveOnClick(View view) {
        setWorking("5");
    }

    public void sixOnClick(View view) {
        setWorking("6");
    }

    public void minusOnClick(View view) {
        setWorking("-");
    }

    public void oneOnClick(View view) {
        setWorking("1");
    }

    public void twoOnClick(View view) {
        setWorking("2");
    }

    public void threeOnClick(View view) {
        setWorking("3");
    }

    public void plusOnClick(View view) {
        setWorking("+");
    }

    public void historyOnClick(View view) {
        //startActivity(new Intent(MainActivity.this, History.class));
        Intent intent = new Intent(MainActivity.this, History.class);
        intent.putExtra("key", historyArray);
        startActivity(intent);
    }

    public void zeroOnClick(View view) {
        setWorking("0");
    }

    public void decimalOnClick(View view) {
        setWorking(".");
    }
}